docker exec -it baseball psql -U postgres
